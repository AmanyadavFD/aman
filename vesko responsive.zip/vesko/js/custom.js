/*=======================================
				Services
=========================================*/
$(document).ready(function () {

    new WOW().init();
});

/*=======================================
				Work
=========================================*/
$(document).ready(function () {

    $('#work').magnificPopup({
        delegate: 'a',
        type: 'image',
        gallery: {
            enabled: true
        }
    });
});

/*=======================================
				Team
=========================================*/
$(document).ready(function () {

    $('#team-members').owlCarousel({
        item: 3,
        autoplay: true,
        smartSpeed: 700,
        loop: true,
        autoplayHoverPause: true,
        responsive:{
        0:{
            items:1
        },
        480:{
            items:2
        },
        768:{
            items:3
        }        
    }
    });
});

/*=======================================
                testimonials
=========================================*/
$(document).ready(function () {

    $("#customers-testimonials").owlCarousel({
        items: 1,
        autoplay: true,
        smartSpeed: 700,
        loop: true,
        autoplayHoverPause: true
    });
});
/*=======================================
                Stats
=========================================*/
$(document).ready(function () {
    $('.counter').counterUp({
        delay:10,
        time:3000
    });
});

/*=======================================
				client
=========================================*/
$(document).ready(function () {

    $('#clients-wrapper').owlCarousel({
        item: 7,
        autoplay: true,
        smartSpeed: 700,
        loop: true,
        autoplayHoverPause: true,
        responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        768:{
            items:5
        },
        992:{
            items:6
        }
    }
      
 

    });
});

/*=======================================
				Navgiation
=========================================*/
$(document).ready(function() {
    
    $(window).scroll(function() {

        if ($(this).scrollTop() < 50) {
            // hide nav
            $('nav').removeClass('vesko-nav-top');
            $('#back-to-top').fadeOut();
            

        } else {
            // show nav
			 $('nav').addClass('vesko-nav-top');
               $('#back-to-top').fadeIn();
            
        }
    });
});

/*=======================================
				Smooth Scroll
=========================================*/
$(function () {
    $("a.smooth-scroll").click(function (event) {
        event.preventDefault();
        // get/return id like #about, #work, #team and etc
        var section = $(this).attr("href");
        $('html, body').animate({
            scrollTop: $(section).offset().top - 64
        }, 1250);
    });
});

/*===============================
    close mobile menu on click
================================*/ 

$(function () {
   $(".navbar-collapse ul li a").on("click touch" , function(){
    $(".navbar-toggle").click();
   });
});